There is one build folder and three theme folders provided.

HTML_build
This folder contains the raw html build. It just has html, css and images, with no specific modifications made for WordPress yet.

muffintop1
This folder contains the theme as it was ready to be uploaded. All the initial files are in there and the index.html has been renamed to index.php. There is no WordPress code in the files yet.

muffintop2
This folder contains the theme as it was when all the initial WordPress functions had been inserted into index.php. It is a functional theme but has no template files yet.

muffintop3
This folder contains the theme was it was at the end of the chapter. It's been broken up into standard template files and one custom template has been added.
