		<div style="clear: both">&nbsp;</div>
	</div><!-- /content -->
	
	<div id="footer">
		<a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a> is powered by wordpress
	</div><!-- /footer -->

</div><!-- /container -->

</body>
</html>