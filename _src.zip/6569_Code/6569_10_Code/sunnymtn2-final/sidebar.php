<div id="sidebar">
	<h3>Monthly Archive</h3>
	<ul>
		<?php wp_get_archives('cat=1'); ?>
	</ul>
</div>