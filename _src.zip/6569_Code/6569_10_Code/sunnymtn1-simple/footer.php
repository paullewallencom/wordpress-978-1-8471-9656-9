		<div style="clear: both">&nbsp;</div>
	</div><!-- /content -->
	
	<div id="footer">
		<b>Sunny Mountain Family Farm</b>  |  Located in Sunny County, MN  |  All content &copy; 2009, SMFF
		<ul>
			<?php wp_list_pages('title_li=' ); ?>
		</ul>
	</div><!-- /footer -->

</div><!-- /container -->

</body>
</html>