There is one HTML build folder, two theme folders, one plugin and one xml export provided.

HTML_build
This folder contains the raw html build. It just has html, css and images, with no specific modifications made for WordPress.

sunnymtn1
This folder contains the theme in its primary simple state. It has just the most basic template files: index.php, header.php, footer.php. It has no particular modifications for the site itself yet.

sunnymtn2
This folder contains the theme was it was at the end of the chapter. It's been broken up into all of the template files created by the end of the chapter.

sunny-mountain.xml
This is a content export from WordPress at the end of the chapter. Note that, if you want to import this into your installation of WordPress, you may want to do a search-and-replace on the file first to change the baseurl from http://sunnymountain:8888 to your own WordPress installation baseurl.

ahs_textsnippets.zip
This is the Text Snippet plugin used in Chapter 10. If you're using WordPress 2.7 or later, you can simply upload the zip via the Add New Plugin page. Otherwise, you have to unzip it and place the php file in /wp-content/plugins and then activate it in WP-Admin.
