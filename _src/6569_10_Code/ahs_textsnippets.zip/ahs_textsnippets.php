<?php
/*
Plugin Name: Text Snippet
Plugin URI: http://springthistle.com/wordpress/plugin_textsnippets
Description: Makes it easy to add multiple snippets of text to your theme's template and update them via the admin panel. Just put <code>&lt;?php get_textsnippet(); ?&gt;</code> in your theme's template, using the number of the snippet as an argument.
Version: 2.0
Author: April Hodge Silver
Author URI: http://springthistle.com

** Copyright 2008  April Hodge Silver **

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/

// PLUGIN SETTINGS
// How Many Text Boxes Do You Want?

   $num = 3;


//-- DO NOT EDIT BELOW! --------------------------------------------------------------------

// can be called in a template file
function get_textsnippet($choose=1) {
	// the default is box #1
	$snippet = get_option('ahs_textsnippet'.$choose);
	if (!empty ($snippet))
		echo '<div class="ahs_textsnippet item-'.$choose.'">'.stripslashes($snippet).'</div>';
}

// used when the plugin is activated
function set_textsnippet_options() {
	global $num;
	for ($i=1;$i<=$num;$i++)
		add_option("ahs_textsnippet".$i);
}

// used when the plugin is deactivated
function unset_textsnippet_options () {
	global $num;
	for ($i=1;$i<=$num;$i++)
		delete_option("ahs_textsnippet".$i);
}

// adds our new option page to the admin menu
function modify_menu_for_textsnippet() {
	add_management_page(
		'Text Snippets',	// Page <title>
		'Text Snippets', // Menu title
		7,				// What level of user
		__FILE__,            //File to open
		'textsnippet_options'  //Function to call
		);  
}

// shows the option page
function textsnippet_options () {
  echo '<div class="wrap"><h2>Your Text Snippets</h2>';
  if ($_REQUEST['submit']) {
	   update_textsnippet_options();
  }
  print_textsnippet_form();
  echo '</div>';
}

function update_textsnippet_options() {
  global $num;
  $updated = false;

  for ($i=1;$i<=$num;$i++)
  	if ($_REQUEST['ahs_textsnippet'.$i]) {  update_option('ahs_textsnippet'.$i, $_REQUEST['ahs_textsnippet'.$i]); $updated = true; }

  if ($updated) {
		echo '<div id="message" class="updated fade">';
		echo '<p>Your Text Snippets were successfully updated!</p>';
		echo '</div>';
   } else {
		echo '<div id="message" class="error fade">';
		echo '<p>Unable to update your Text Snippets!</p>';
		echo '</div>';
   }
}

function print_textsnippet_form () {

	global $num;
	
	echo "<p>By default, this plugin allows you to have 3 text snippets. You can easily change this by editing the plugin file itself and changing the first line, <code>\$num = 3</code>, to any other number you need.</p><p>Below, just enter the text for each text snippet. Once you've got something in there, you can add the function <code>get_textsnippet(ID);</code> anywhere in your theme's template and the text you save here will appear in that spot. Use the text snippet numbers (e.g. 1) as an argument in the function to replace <code>ID</code>.</p>";
	echo '<form method="post"><table cellpadding="5">';
	
	for ($i=1;$i<=$num;$i++) {
		$textsnippet = stripslashes(get_option('ahs_textsnippet'.$i));
		echo '<tr>';
		echo '<td valign="top"><h2>'.$i.'</h2></td>';
		echo '<td><textarea rows="6" cols="60" name="ahs_textsnippet'.$i.'">'.$textsnippet.'</textarea><p>&nbsp;</p></td>';
		echo '</tr>';
	}

	echo '</table><input type="submit" name="submit" value="Save Changes" />';
	echo "</form>";

}
add_action('admin_menu','modify_menu_for_textsnippet');
register_activation_hook(__FILE__,"set_textsnippet_options");
register_deactivation_hook(__FILE__,"unset_textsnippet_options");

?>
